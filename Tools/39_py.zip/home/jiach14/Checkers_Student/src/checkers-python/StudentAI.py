import random
import math
import copy
import sys
from BoardClasses import Board, Move

class MCTSNode:
    def __init__(self, board, parent=None, last_move=None, color_to_move=1):
        """
        MCTS tree node for Monte Carlo Tree Search.
        """
        self.board = board
        self.parent = parent
        self.children = {}
        self.visits = 0
        self.wins = 0
        self.untried_moves = []
        self.color_to_move = color_to_move
        self.last_move = last_move

    def is_terminal_node(self):
        """ Check if the game is over at this node. """
        return self.board.is_win(1) != 0 or self.board.is_win(2) != 0

    def is_fully_expanded(self):
        """ A node is 'fully expanded' if all possible child moves have been explored. """
        return len(self.untried_moves) == 0

    def q(self):
        """ Returns the average win rate. """
        return float(self.wins) / self.visits if self.visits > 0 else 0

    def ucb1(self, exploration_constant):
        """ Upper Confidence Bound (UCB1) formula for tree expansion. """
        if self.visits == 0:
            return float('inf')
        return self.q() + exploration_constant * math.sqrt(math.log(self.parent.visits) / self.visits)

class StudentAI:
    def __init__(self, col, row, p):
        """
        AI Player using Monte Carlo Tree Search (MCTS) with advanced heuristics.
        """
        print("DEBUG: StudentAI with MCTS + heuristic-based rollouts", file=sys.stderr)
        self.col = col
        self.row = row
        self.p = p
        self.board = Board(col, row, p)
        self.board.initialize_game()

        self.first_turn = True
        self.color = None
        self.opponent = {1: 2, 2: 1}

        # MCTS Parameters
        self.num_simulations = 3000
        self.exploration_param = math.sqrt(2)
        self.max_rollout_depth = 500

    def get_move(self, move):
        """ Main function to get the best move using MCTS. """
        if self.first_turn:
            self.first_turn = False
            self.color = 1 if len(move) == 0 else 2

        if len(move) != 0:
            self.board.make_move(move, self.opponent[self.color])

        movesets = self.board.get_all_possible_moves(self.color)
        if not movesets:
            return Move([])

        root = MCTSNode(copy.deepcopy(self.board), color_to_move=self.color)
        root.untried_moves = self._get_all_moves(root.board, root.color_to_move)

        for _ in range(self.num_simulations):
            node = self._select(root)
            if not node.is_terminal_node() and node.untried_moves:
                node = self._expand(node)
            result = self._simulate(node)
            self._backpropagate(node, result)

        best_child = self._best_child(root, exploration=0)
        best_move = best_child.last_move
        self.board.make_move(best_move, self.color)
        return best_move

    def _select(self, node):
        """ Select the best node using UCB1 with early pruning of losing moves. """
        while not node.is_terminal_node() and node.is_fully_expanded():
            best_child = self._best_child(node, self.exploration_param)
            if best_child.q() < -0.8:
                break
            node = best_child
        return node

    def _expand(self, node):
        """ Expand a child node prioritizing capture moves. """
        if not node.untried_moves:
            return node

        capture_moves = [move for move in node.untried_moves if len(move.seq) > 1]
        move = capture_moves.pop() if capture_moves else node.untried_moves.pop()

        node.untried_moves.remove(move)
        new_board = copy.deepcopy(node.board)
        new_board.make_move(move, node.color_to_move)

        next_color = self.opponent[node.color_to_move]
        child_node = MCTSNode(new_board, node, move, next_color)
        child_node.untried_moves = self._get_all_moves(new_board, next_color)
        node.children[move] = child_node
        return child_node

    def _simulate(self, node):
        """ Run a heuristic-based rollout instead of pure random play. """
        board_copy = copy.deepcopy(node.board)
        color_to_move = node.color_to_move
        depth = 0

        while depth < self.max_rollout_depth:
            if board_copy.is_win(self.color) == self.color:
                return +1.0
            elif board_copy.is_win(self.opponent[self.color]) == self.opponent[self.color]:
                return -1.0

            movesets = board_copy.get_all_possible_moves(color_to_move)
            if not movesets:
                return -1.0 if color_to_move == self.color else +1.0

            depth += 1
            all_moves = [m for group in movesets for m in group]
            capture_moves = [m for m in all_moves if len(m.seq) > 1]
            king_moves = [m for m in all_moves if m.seq[-1][0] in {0, self.row - 1}]

            move = random.choice(capture_moves) if capture_moves else \
                   random.choice(king_moves) if king_moves else \
                   random.choice(all_moves)

            board_copy.make_move(move, color_to_move)
            color_to_move = self.opponent[color_to_move]

        return self._heuristic_evaluation(board_copy)

    def _backpropagate(self, node, result):
        """ Backpropagate simulation results up the tree. """
        while node:
            node.visits += 1
            node.wins += result
            node = node.parent

    def _best_child(self, node, exploration):
        """ Select the best child using UCB1. """
        return max(node.children.values(), key=lambda child: child.ucb1(exploration) if exploration > 0 else child.q())

    def _get_all_moves(self, board, color):
        """ Get all moves, prioritizing captures and forward movement. """
        movesets = board.get_all_possible_moves(color)
        capture_moves = []
        forward_moves = []
        other_moves = []

        for group in movesets:
            for move in group:
                start_row, _ = move.seq[0]  # Initial position
                end_row, _ = move.seq[-1]  # Final position

                if len(move.seq) > 1:  # Capture moves
                    capture_moves.append(move)
                elif (color == 1 and end_row > start_row) or (color == 2 and end_row < start_row):
                    forward_moves.append(move)  # Moves towards king row
                else:
                    other_moves.append(move)

        if capture_moves:
            return capture_moves
        elif forward_moves:
            return forward_moves
        else:
            return other_moves


    def _heuristic_evaluation(self, board):
        """ Evaluate board position considering piece count, mobility, and King safety. """
        my_color = self.color
        opp_color = self.opponent[my_color]

        # **Updated Weights**
        REGULAR_PIECE_VALUE = 1
        KING_VALUE = 7  # Kings are now much stronger
        MOBILITY_WEIGHT = 0.5
        KING_SAFETY_WEIGHT = 3.0  # Stronger emphasis on keeping Kings safe

        my_score = 0
        opp_score = 0

        my_moves = board.get_all_possible_moves(my_color)
        opp_moves = board.get_all_possible_moves(opp_color)
        mobility_score = (len(my_moves) - len(opp_moves)) * MOBILITY_WEIGHT

        for r in range(self.row):
            for c in range(self.col):
                piece = board.board[r][c]
                if piece:
                    color = piece.get_color()
                    value = KING_VALUE if piece.is_king else REGULAR_PIECE_VALUE

                    if piece.is_king:
                        if c in {0, self.col - 1}:  # Kings on edges are weaker
                            value -= KING_SAFETY_WEIGHT  
                        else:
                            value += KING_SAFETY_WEIGHT  # Kings in the middle are safer

                    if color == my_color:
                        my_score += value
                    else:
                        opp_score += value

        return (my_score - opp_score) + mobility_score

